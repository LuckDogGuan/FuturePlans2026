# 外设、架构、QEMU 与 PCIe：资料核查及实验边界

核查日期：2026-10-19。用途：为逐周计划提供可定位的课程、规范与实验入口。本文的章节号仅指明确标注的教材版本，不能直接当作 B 站 P 号。实验是学习设计，未在本轮执行；不代表现有板卡已具备相应硬件能力。

## 1. 平台怎么分工

| 平台 | 学到什么 | 必须交付什么 | 不能据此声称什么 |
|---|---|---|---|
| i.MX6ULL / Cortex-A7 / Armv7-A 真板 | 寄存器、引脚复用、时钟、IRQ、GPIO/PWM/UART/I2C/SPI、Linux 驱动 | 手册页码、寄存器位表、原理图网络名、示波器/逻辑分析仪证据 | 不能把该平台当 AArch64；不能假定它有 PCIe |
| QEMU Arm `virt` / AArch64 | A64 指令、ABI、异常、页表、通用 UART/GIC、PCI 软件路径 | 固定 QEMU 版本和机器参数、GDB 记录、DTB、可重复启动脚本 | `virt` 不是 i.MX6ULL 仿真，不复现板级时钟、布线和真实外设时序 |
| QEMU RISC-V `virt` / RV64 | 第二种 ISA、CSR、trap、Sv39、xv6 的调度与锁 | 同一 C 例程的两套反汇编、trap 路径、锁与唤醒时序图 | 不要求转向 RTL/流片；不等同于任意国产 RISC-V SoC BSP |
| QEMU EDU | PCI 枚举、BAR、MMIO、INTx/MSI、DMA、卸载 | 自写驱动、错误注入、重复 bind/unbind 日志 | 传统 PCI 教学模型不证明完整 PCIe 链路、带宽、电气或真实一致性 |
| 后期独立 PCIe RC/EP 硬件 | PHY/时钟/reset、链路训练、RC/EP、DT、DMA/IRQ、恢复 | 板卡手册、LinkSta、测试数据、异常恢复记录 | 不能由 QEMU 成功代替实板通过 |

依据：[NXP i.MX6ULL 产品及文档页](https://www.nxp.com/products/i.MX6ULL?tab=Documentation_Tab)、[QEMU Arm 系统仿真](https://www.qemu.org/docs/master/system/target-arm)、[Arm virt](https://www.qemu.org/docs/master/system/arm/virt.html)、[RISC-V virt](https://www.qemu.org/docs/master/system/riscv/virt.html)。`master/latest` 文档会变化，开始实验时记录本地 QEMU 可执行程序的 `--version` 输出、内核版本及源码 commit，并切到匹配版本文档。

## 2. i.MX6ULL：把项目中的背光、按键、采集和传感器追到底

### 2.1 官方手册的用途

- [NXP 文档总入口](https://www.nxp.com/products/i.MX6ULL?tab=Documentation_Tab)：已经核实存在 `IMX6ULLRM`（i.MX 6ULL Applications Processor Reference Manual）、`IMX6ULLCE`（勘误）、`IMX6ULLHDG`（硬件开发指南）、`IMX6ULLEVKHUG`（EVK 硬件指南）。RM 下载可能要求 NXP 账号。不要把 Linux Reference Manual 或相近的 IMX6ULRM 当作 IMX6ULLRM。
- [Arm Cortex-A7 官方页](https://www.arm.com/products/silicon-ip-cpu/cortex-a/cortex-a7)：进入 Cortex-A7 TRM；[Arm 官方 TRM PDF](https://documentation-service.arm.com/static/602cf701083323480d479d18?token=)。TRM 解释处理器实现；SoC 引脚、时钟和外设寄存器由 NXP RM/板卡原理图解释。两本互补。
- 手册检索词：`IOMUXC`、`CCM`、`GPIO`、`UART`、`I2C`、`ECSPI`、`PWM`、`SDMA`、`Interrupt`。本轮未逐页核实 NXP RM 各章号，因此除下述已由野火正文引用的 PWM Chapter 38 外不编造数字。

### 2.2 中文主教材：已核实的章节定位

[野火官方新目录](https://doc.embedfire.com/linux/imx6/driver/zh/latest/index.html)分为“i.MX6 裸机开发”“LINUX 驱动基础知识”“Linux 驱动框架”“Linux 驱动进阶知识”，每部分章节号重新从 1 计。下面是文档章节号。

| 方向 | 精确定位与链接 | 学习偏向与项目交付 |
|---|---|---|
| 从汇编到 C 的 MMIO | 裸机第 4 章《汇编点亮LED灯》、第 5 章《LED灯进阶——C语言实现》、第 6 章《完善LED程序》，从[官方目录](https://doc.embedfire.com/linux/imx6/driver/zh/latest/index.html)进入 | 用屏幕背光 enable 作映射练习：地址从哪来，基址+偏移怎么算，一次读改写会影响哪几个位；区分普通 R/W、只读、W1C 和保留位 |
| 按键与中断 | 裸机第 8 章《GPIO输入—按键查询检测》、第 10 章《中断》、第 11 章《时钟控制模块（CCM）》；框架第 4 章《中断子系统–按键中断实验》 | 为“按键启动拍摄”画出引脚电平→中断控制器→ISR→工作队列/等待队列→用户态路径；做抖动、长按、重复触发、并发关闭 |
| UART | 裸机第 12 章[《UART—串口通讯》](https://doc.embedfire.com/linux/imx6/driver/zh/latest/bare_metal/uart.html) | 从波特率、起止位、FIFO 到字节状态机；除了发送接收，还要区分帧错误、超时、半包、CRC、缓存所有权，逻辑分析仪对照实际位流 |
| Linux 设备模型 | 基础第 6 章《Linux的设备模型》、第 7 章《平台设备驱动》、第 8 章[《Linux设备树》](https://doc.embedfire.com/linux/imx6/driver/zh/latest/linux_driver/driver_tree.html)、第 9/10 章设备树与插件 RGB 驱动 | 在设备树、匹配表、probe、资源获取、用户接口之间追踪；解释设备描述与驱动代码各负责什么；记录实际内核/DTB 来源 |
| GPIO/pinctrl | 框架第 1 章[《pinctrl子系统和gpio子系统-led实验》](https://doc.embedfire.com/linux/imx6/driver/zh/latest/linux_driver/gpio_subsystem.html) | GPIO 控制器、mux、pad 电气属性分开；映射相机复位/背光使能，日志读回只证明软件状态，输出电平和负载效果另测 |
| I2C | 框架第 2 章《I2C子系统–mpu6050驱动实验》，从[目录](https://doc.embedfire.com/linux/imx6/driver/zh/latest/index.html)进入 | 结合角度采集：地址与寄存器地址区别、重复起始、ACK/NACK、多字节顺序、符号扩展、量程、时间戳；读失败返回原因，不能填假角度 |
| SPI | 框架第 3 章《SPI子系统–OLED屏实验》，从[目录](https://doc.embedfire.com/linux/imx6/driver/zh/latest/index.html)进入 | CPOL/CPHA、位序、CS 边界、全双工、传输长度；用屏幕命令/像素字节分析“同一字节怎样从内存到引脚” |
| PWM | 框架第 6 章[《PWM子系统–pwm波形输出实验》](https://doc.embedfire.com/linux/imx6/driver/zh/latest/linux_driver/pwm_sub_system.html) | 对应背光：时钟→分频→周期→占空比→有效极性；测 0%、中间档、100%，保存频率/波形/实际亮度证据。该正文指向 NXP RM Chapter 38 PWM |
| 竞争与关闭 | 进阶第 1 章《linux驱动并发与竞态》，从[目录](https://doc.embedfire.com/linux/imx6/driver/zh/latest/index.html)进入 | 并发 open/read/ioctl/close、设备卸载、回调仍在运行等场景；逐个定义状态、锁、引用和资源寿命 |

版本限制：[野火关于本项目](https://doc.embedfire.com/linux/imx6/driver/zh/latest/README.html)说明教材采用 4.19 系列；[野火官方资料索引](https://doc.embedfire.com/products/link/zh/latest/linux/ebf_i.mx6ull_doc.html)提醒镜像与视频有差异。旧课可以学机制，API 必须对照自己锁定的内核；GPIO 优先核查 descriptor API，新旧 PWM API 也不可混抄。

### 2.3 视频与 DMA 的补齐

- 中文配套视频：[野火第四期 Linux“驱动开发”篇](https://www.bilibili.com/video/BV1pf4y1974n/)。搜索结果核实课程标题、平台与发布方信息；直接打开返回 412，本轮没有核实完整分 P 列表，故不提供伪 P 号。定位关键词：“野火 Linux 设备树”“pinctrl gpio”“I2C mpu6050”“SPI OLED”“PWM 子系统”“Linux 驱动并发与竞态”。视频题名与上表章节对照，不能强行一一编号。
- DMA：本轮野火新目录没有查到独立 DMA 专章。补读 Linux 官方[DMA Engine API Guide](https://docs.kernel.org/driver-api/dmaengine/client.html)，重点按其 `DMA usage` 中的 request channel、configure、prepare descriptor、submit、issue pending、completion、terminate 顺序学习；不要把“DMAengine 客户端”和“自己实现 DMA 控制器驱动”混为一件事。
- 同时读[Dynamic DMA mapping Guide](https://docs.kernel.org/core-api/dma-api-howto.html)：区分 CPU 虚拟地址、物理地址、DMA/bus 地址；coherent 与 streaming、方向、map/unmap、sync、错误检查。**coherent 不等于 CPU/设备观察顺序自动正确**。
- 项目练习：用模拟采样块先做 buffer 生命周期图，再用 QEMU EDU 完成可重复 DMA；真板仅在确认控制器、驱动、数据路径和外设支持后进入 UART/SPI DMA。不能为了“覆盖 DMA”绕过已有稳定驱动直接写在线业务寄存器。

## 3. Armv8-A / AArch64：软件接口优先，按问题精读

以下标题已经在 [Arm Learn the Architecture A-profile 官方目录](https://www.arm.com/architecture/learn-the-architecture/a-profile)核实；直接文档子页会跳转 `support.arm.com`，部分网页抓取为空，可从官方目录进入并下载 PDF。

| 阅读顺序与精确文档标题 | 必读点 | 可做的小实验 |
|---|---|---|
| AArch64 Instruction Set Architecture (ISA) | A64、通用寄存器、load/store、符号/零扩展、条件分支 | 同一解码器分别编译 Armv7/AArch64，标出 byte/halfword/word 读取指令和地址计算 |
| AArch64 Exception Model | EL0–EL3、同步异常、IRQ/FIQ/SError、异常入口/返回 | QEMU+GDB 在异常向量处停止，记录 PC、返回地址、异常原因与栈；区分 Linux signal 和 CPU exception |
| AArch64 Memory Management | VA→PA、页表、权限、TLB | 画 1 个地址的翻译路径，在实验系统观察页故障；不在用户态假定可直接读系统寄存器 |
| AArch64 Memory Attributes and Properties | Normal/Device 内存、cacheability、shareability | 比较普通缓冲与 MMIO 的访问约束；解释为何寄存器不是普通结构体 |
| Memory Systems, Ordering, and Barriers | CPU/编译器重排、屏障适用范围 | 为描述符字段、ownership 位、doorbell 顺序逐条写理由；QEMU 未复现乱序不能当真板正确性证据 |
| Software Synchronization Primitives in A64 | exclusive/atomic、同步原语 | 用锁或原子实现生产者/消费者；对照反汇编；不从 `volatile` 推出线程安全 |
| Generic Interrupt Controller v3 and v4, Overview | 控制器职责、路由、使能/屏蔽/确认 | 对照 QEMU 参数与 DT 的控制器版本，追踪设备 IRQ 到处理函数；不把 GICv3 配置照搬 A7 真板 |

官方视频入口：[Arm On Demand Training](https://developer.arm.com/dev2/Training/Arm%20On-demand%20Training)。已核实模块名包括 `Introduction to Armv7-A Architecture`、`Introduction to Armv8-A Architecture`、`Introduction to GICv3/v4 Architecture`、`Introduction to Arm CoreSight`；页面说明有简体/繁体中文译稿，但访问需咨询或订阅，不能称全部免费可看。先使用免费官方文档，能访问视频时再补；不让付费视频成为实验的前置阻塞。

## 4. RISC-V：用第二种 ISA 检查“哪些知识可迁移”

- [官方 ISA 总入口](https://docs.riscv.org/reference/isa/index.html)本轮指向 `v20260120`。已核实[Volume I: Unprivileged](https://docs.riscv.org/reference/isa/v20260120/unpriv/unpriv-index.html)及[Volume II: Privileged](https://docs.riscv.org/reference/isa/v20260120/priv/priv-index.html)可打开。书卷版本和各扩展版本不同，笔记要同时记版本。
- 第一轮只精读标题：`RV32I Base Integer Instruction Set` 中寄存器/编码/load-store/分支，接着 `RV64I Base Integer Instruction Set`；补 `M`、`A`、`Zicsr`、`Zifencei` 与内存模型。不要把所有向量/密码/厂商扩展列为入门必修。
- 特权部分按标题找 Machine-Level ISA、Supervisor-Level ISA；重点 trap CSR、`satp`、Sv39、权限、委托和中断。新版网页编号变化，本计划以标题定位，不沿用旧视频章号。
- [QEMU RV64 virt](https://www.qemu.org/docs/master/system/riscv/virt.html)有通用 RV32GC/RV64GC、UART、PLIC、PCIe host bridge 等模型。外设地址和 IRQ 从当前 DT/源码核对，不因为 ISA 相同就跨板照抄地址。
- 官方会议视频：[RISC-V International《Privileged ISA》](https://www.youtube.com/watch?v=fxLXvrLN5jA)，Allen Baum，2018 年工作坊。适合看设计动机，CSR/异常细节必须以当前规范校正；不能把旧报告当最新版操作手册。

MIT [6.1810 Fall 2025 官方课程表](https://pdos.csail.mit.edu/6.1810/2025/schedule.html)可作为系统层主线，章节/讲次已核实：

| 讲次 | 课程原题 | 对应训练 |
|---|---|---|
| LEC 2 | C in xv6 and examples | 指针、结构体、函数边界与内核代码阅读 |
| LEC 5 | Page tables | 页表与寻址，配 `pgtbl` lab |
| LEC 6 | System call entry/exit | C/汇编边界与 trapframe |
| LEC 8 | Page faults | 异常原因、修复路径和可复现实验 |
| LEC 11 | Device drivers | 16550 UART、中断、缓冲 |
| LEC 12 | Locking | 临界区、锁顺序、死锁 |
| LEC 13 | Thread switching | 栈、上下文切换与调度 |
| LEC 14 | Coordination | sleep/wakeup、条件与丢唤醒 |

课程表提醒部分视频/笔记沿用上一年；视频是否存在按页面当时实际链接为准。2025 LEC 编号不能直接套在 2020 视频上。实验建议：先 xv6 util/syscall，再少量 pgtbl/traps/lock；每次只改一个机制，提交补丁、失败例和 GDB 证据，不要求一年内刷完全部实验。

## 5. QEMU 用法：验证逻辑，保留模拟边界

读官方[Arm virt](https://www.qemu.org/docs/master/system/arm/virt.html)、[RISC-V virt](https://www.qemu.org/docs/master/system/riscv/virt.html)及[GDB 使用说明](https://www.qemu.org/docs/master/system/gdb.html)。以下是待适配的启动骨架，不是已验证可直接运行的成品命令；`Image`、rootfs 和内核配置必须匹配架构。

```sh
qemu-system-aarch64 -M virt -cpu cortex-a53 -m 512M -nographic \
  -kernel Image -initrd rootfs.cpio.gz \
  -append 'console=ttyAMA0 rdinit=/init' -S -gdb tcp:127.0.0.1:1234

qemu-system-riscv64 -M virt -m 512M -nographic \
  -kernel Image -initrd rootfs.cpio.gz \
  -append 'console=ttyS0 rdinit=/init' -S -gdb tcp:127.0.0.1:1234
```

RISC-V 示例依赖所装 QEMU 提供的默认 OpenSBI；裸机程序/xv6 与 Linux 的加载方式分别遵循对应项目。调试端口仅用于本机实验，避免与其他调试进程冲突。每个架构保存 `--version`、`-machine help`、`-cpu help`、启动参数、内核 `.config`、DTB 和串口日志。

每次实验回答五个问题：CPU 处于什么执行状态/特权级；指令从何地址取；数据地址如何计算；异常送到哪里；设备如何通知 CPU。把代码与位级证据连起来，而不是只留“启动成功”截图。

## 6. PCI/PCIe 的学习顺序与验收

### 6.1 先用 EDU 把 PCI 驱动写完整

[EDU 官方规范](https://www.qemu.org/docs/master/specs/edu.html)核实：PCI ID `1234:11e8`；BAR0 为 1 MiB MMIO；低于 `0x80` 的访问限 32 位；后续允许 32/64 位；默认 DMA mask 28 位；提供 INTx 和 MSI。设备支持 MSI 时仍需确认中断状态。教学实验不能凭空扩为 MSI-X、多队列或真实 PCIe 能力。

建议顺序：①枚举与 BAR；②寄存器存活测试；③轮询完成；④INTx；⑤MSI；⑥DMA 与超时；⑦关闭/卸载/错误路径。对照[Linux How To Write PCI Drivers](https://docs.kernel.org/PCI/pci.html)的 `Device Initialization Steps` 与释放章节，但不要机械照抄其中历史 API 表述；DMA 以现行 DMA API Guide 为准。

**跨平台 DMA 陷阱**：EDU 默认 28 位只覆盖最低 256 MiB，而 [QEMU Arm virt 源码](https://github.com/qemu/qemu/blob/master/hw/arm/virt.c)的 RAM 起点是 1 GiB。因而把 x86 EDU 示例原封搬到 Arm virt，很可能无法得到设备可寻址的 DMA buffer。第一轮可在 x86 PC guest 完成默认 mask 教学，再迁移 Arm；或在清楚实验目标后同时提高 EDU 模型的 `dma_mask` 属性与驱动协商能力，仍需核查 RAM/IOMMU 映射。只改驱动为 32/64 位而不改模型能力是错误修法。此处为依据地址布局的推断，未执行验证。

| 环节 | 必须讲清/实现 | 验收证据 |
|---|---|---|
| probe 与资源 | ID 匹配→enable→申请 BAR→映射；检查每个返回值 | `lspci -nnvv`、sysfs resource、绑定日志；注入资源获取失败 |
| 寄存器访问 | `__iomem`、访问宽度、字节序、合法位与副作用 | 偏移/宽度/掩码表；拒绝越界请求；不用普通指针直接解引用 MMIO |
| DMA | 在分配前协商实际 mask；CPU 指针和 DMA 地址分别保存；检查 map 失败 | 0/1/边界长度、方向、数据比对、超时，故意降低 mask 的失败说明 |
| IRQ | 先清旧状态，注册处理函数，再允许设备出中断；共享 INTx 判断来源；MSI 分配向量 | `/proc/interrupts` 前后计数、完成事件、重复请求、超时后的状态 |
| 并发 | buffer 属于谁；何时可回收；关闭与在途任务如何协调 | 并发调用和关闭时序图；拒绝新请求后等待/取消在途工作 |
| remove/失败回滚 | 让硬件停止 DMA/IRQ，等待回调退出，再释放 buffer、IRQ、映射、资源 | 重复 bind/unbind 无悬挂访问；部分 probe 失败不泄漏；记录顺序理由 |

IRQ 独立依据：[MSI Driver Guide](https://docs.kernel.org/PCI/msi-howto.html)，重点 `pci_alloc_irq_vectors()`、`pci_irq_vector()`、释放向量与锁。MSI-X 可用支持它的设备另做，不能硬塞给 EDU。DMA 独立依据：[DMA mapping Guide](https://docs.kernel.org/core-api/dma-api-howto.html)。寄存器独立依据：[Bus-Independent Device Accesses](https://docs.kernel.org/driver-api/device-io.html)：使用 I/O accessor，posted write 必要时读取合适寄存器确认到达；不要以加一个 `volatile` 代替。

### 6.2 PCIe 配置要分 RC、EP、驱动三个层面

| 层面 | 官方入口及准确定位 | 学习/实验 |
|---|---|---|
| 配置空间与拓扑 | [QEMU 官方 `docs/pcie.txt`](https://github.com/qemu/qemu/blob/master/docs/pcie.txt)，`PCI Express only hierarchy`、`PCI only hierarchy` | 画 root bus/root port/bridge/endpoint；对照 `lspci -t`。EDU 接入 PCIe 根总线也不会变成真正 PCIe endpoint |
| ECAM 与 DT | [Linux `host-generic-pci.yaml`](https://github.com/torvalds/linux/blob/master/Documentation/devicetree/bindings/pci/host-generic-pci.yaml) | 理解 `reg` 配置窗口、`bus-range`、`ranges`、`interrupt-map`、MSI/IOMMU 关联；计算相对 bus-range 起点的 ECAM 偏移：`(bus-start)<<20 | dev<<15 | fn<<12 | reg` |
| 真板 RC bring-up | 目标 SoC 的 TRM/硬件指南/DT binding + BSP 控制器驱动 | 电源、参考时钟、PERST#、PHY、controller clocks/reset、RC 模式、地址窗口、Link up、枚举，再端点驱动。顺序以该硬件手册为准，不能把 QEMU generic ECAM 当成 DesignWare 真板初始化教程 |
| 真板 EP | [Linux PCI Endpoint Framework](https://docs.kernel.org/PCI/endpoint/index.html)：`PCI Endpoint Core`、`Configuring PCI Endpoint Using CONFIGFS`、`PCI Test Function` | 先确认 SoC/EPC 驱动确实支持 EP；配置函数、vendor/device、BAR、绑定 EPC、启动链路。需要具备 RC 的另一端 |
| RC↔EP 系统验收 | [PCI Test User Guide](https://docs.kernel.org/PCI/endpoint/pci-test-howto.html)：`Endpoint Device` 与 `RootComplex Device` | 用官方 test function/host test 跑 BAR、IRQ、读写/拷贝，再分析超时和复位；只在明确支持的硬件执行 |
| 协议原始定义 | [PCI-SIG Specifications](https://pcisig.com/specifications) | Base Specification 是原始标准入口；完整规范可能受会员/授权限制。暂以公开 Linux/QEMU 文档完成软件实验，不能宣称已免费获取全部规范 |

真板后期再补 LTSSM、lane width/link speed、链路降速与 retrain、AER、热复位/功能级复位、IOMMU；每项确认设备/控制器能力后再验收。QEMU 能验证寄存器与软件路径，不能测差分线信号完整性、真实 refclk/PERST# 时序、眼图和线缆可靠性。i.MX6ULL 与当前工作板是否支持 PCIe 必须查具体芯片与板图；本计划不预设已具备，不据此要求立即买新板。

## 7. 对齐、SIGBUS 和“每一个比特”必须纠正的概念

1. 用户提到的 `halfworld` 按语境应为 **halfword**；`sigbad` 按语境重点训练 **SIGBUS**，同时区分 SIGSEGV。Arm 常用术语 halfword=16 位、word=32 位、doubleword=64 位；Linux `readw/readl` 的命名有历史，必须以 API 说明确认宽度，不能由 C 的 `long` 宽度猜测。
2. 不对齐访问是否成功依赖架构、具体指令、内存属性、控制位和 OS 处理；不能说“Arm 必崩”或“x86 成功所以 C 正确”。[Linux Unaligned Memory Accesses](https://cdn.kernel.org/doc/html/latest/core-api/unaligned-memory-access.html)给出跨架构差异与 `get_unaligned/put_unaligned`、`memcpy` 方案。用户态协议用边界检查+字节拼装或 `memcpy`；内核按该版本 unaligned API；MMIO 另守设备宽度规则，不能用普通 `memcpy` 读取寄存器。
3. 学习性错误样例与正确实现分开运行：先 sanitizer/编译警告检查错误类型，再用 GDB `x/16bx`、反汇编和寄存器观察，不要求所有 QEMU 架构都必须产生 SIGBUS。复现报告记录“预期异常/实际异常/未触发的原因”，不可把未触发写成对齐无要求。
4. [Linux volatile 文档](https://docs.kernel.org/process/volatile-considered-harmful.html)明确其不能代替并发保护。区分编译器、CPU 内存模型、cache 一致性与设备总线顺序；共享数据用适当锁/原子，MMIO 用 accessor，DMA 用 DMA API 和所需屏障。
5. 位域结构体可以用来观察编译器布局，不宜直接作为可移植的线协议或 MMIO 定义。训练应当实际比较 `sizeof/_Alignof/offsetof`、padding、两种编译器反汇编；协议用显式掩码/移位/序列化，寄存器先按手册区分普通 R/W、W1C、read-clear 与 reserved，再决定能否读改写。依据 [Arm 官方 AAPCS32](https://github.com/ARM-software/abi-aa/blob/main/aapcs32/aapcs32.rst)的 `5.3.4 Bit-fields`、`8.1.6 Structure, Union and Class Layout`、`8.1.7 Bit-fields`；其中 volatile bit-field 写入可能包含一次读和一次写，二者不具有原子性，正好适合和 W1C 寄存器风险一起分析。

## 8. 精选视频：质量与可访问性分开记录

| 资源 | 核查状态 | 如何用 |
|---|---|---|
| [Bootlin Device Tree 101：官方视频和课件入口](https://bootlin.com/blog/device-tree-101-webinar-slides-and-videos/) | 官方页面核实两场录像与课件；英文；本轮未核实中文 CC | 在设备树阶段看完整语法/继承/bindings/驱动关系，做一个 DT 节点到 probe 的证据链 |
| [Bootlin kernel training](https://bootlin.com/training/kernel/) | 免费教材/实验核实；商业直播培训不等于免费完整录像 | 用课件+串口驱动/I2C 实验补中文课，遇到 API 差异查固定内核 |
| [Bootlin 官方公开演讲目录](https://bootlin.com/docs/) | 已核实包括 `From the camera sensor to the user: the journey of a video frame`（2020）、`Advanced camera support on Allwinner SoCs with mainline Linux`（2022）等视频条目 | 摄像头工作相关扩展：先画 sensor→总线→DMA/buffer→用户态路径，具体 SoC 差异单列；不把 Allwinner 寄存器抄到 Luckfox |
| [Arm On Demand Training](https://developer.arm.com/dev2/Training/Arm%20On-demand%20Training) | 官方、列出中文译稿；访问条件见上文 | Armv7-A→Armv8-A→GIC/CoreSight，先基础后调试 |
| [RISC-V International Privileged ISA](https://www.youtube.com/watch?v=fxLXvrLN5jA) | 官方账号与会议来源核实，2018，细节可能过时 | 只用作概念引导，规范版本对照表必须补 |
| [MIT 6.1810 2025](https://pdos.csail.mit.edu/6.1810/2025/schedule.html) | 官方讲次、阅读、实验核实；不同年份录像有复用 | 按上表精确讲次进入，系统实验与源代码为交付 |

没有核实的视频字幕/机翻条件一律不保证。推荐检索格式：`讲者/发布方 + 完整题名 + 年份`；观看时必须产生代码、位图、时序图、抓包或调试记录之一，不能用观看时长替代能力验收。
