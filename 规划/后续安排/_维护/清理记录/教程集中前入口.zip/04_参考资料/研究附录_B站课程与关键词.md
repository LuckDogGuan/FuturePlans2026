# B站课程补充目录：只补现行计划的缺口

目录信息来自2026-10-05核查；2026-10-19按芯片软件主线精简。没有本轮逐节重新播放，不保证分P、字幕或访问条件保持不变。课程不是另一套学习顺序，必修章节以[现行资料表](../规划/后续安排/资料/01_C与系统课程章节核查.md)和[周计划](../规划/后续安排/03_逐周目录.md)为准。

## 中文基础与工具备选

| 课程与作者入口 | 旧目录已核定位 | 当前用途与限制 |
|---|---|---|
| [于仕琪：南科大C/C++](https://www.bilibili.com/video/BV1Vf4y1P7pq/)，[作者代码](https://github.com/ShiqiYu/CPP) | 1.3编译链接；5.1～5.4指针内存；6.2～6.3参数 | 指针/内存的另一种讲法；C++引用、new/delete、类与C规则分开，C主讲仍按新计划 |
| [爱编程的大丙：gcc/库/Makefile/GDB](https://www.bilibili.com/video/BV13U4y1p7kB/) | 7章gcc、8章静态动态库、10章GDB | 只补构建/定位；GDB选项查当前官方手册 |
| [蒋炎岩OS2024](https://jyywiki.cn/OS/2024/) | 实际讲次及官方B站入口见新资料表 | 第8讲调试、第9/12讲并发、第14/15讲进程地址空间、第21讲中断上下文，第26/27讲设备驱动 |
| [九曲阑干CSAPP入口](https://www.bilibili.com/video/BV1cD4y1D7uR/) | 对应教材第3章机器级、第6章cache、第7章链接、第8/9章异常与虚拟内存 | 中文辅助，不能将x86寄存器/ABI照搬ARM；以CMU官方课件和实际ISA核查 |
| [小彭现代CMake](https://www.bilibili.com/video/BV16P4y1g7MH/)，[作者仓库](https://github.com/parallel101/course) | 按target/include/link主题检索，不编单集编号 | 仅当核心库+CLI构建遇到问题时补看，不刷整套高阶模板 |

## 已有野火板：官方视频与教材

| 官方视频 | 已核旧定位 | 当前用法 |
|---|---|---|
| [第一期零基础入门](https://www.bilibili.com/video/BV1JK4y1t7io/) | 19运行板；26～29交叉编译；39～44文件IO | 缺环境时补，不要求重新刷现有系统 |
| [第二期内核编程](https://www.bilibili.com/video/BV1PK411T7MA/) | 48～53进程；58～67 IPC/信号/共享内存 | 多为系统API，不等于已经完成内核研发 |
| [第四期驱动开发](https://www.bilibili.com/video/BV1pf4y1974n/) | 旧目录89～99模块/字符设备，110～115设备树 | 旧分P仅作历史索引；本轮文档分册和精确章名见新硬件资料，不能把两种编号混用 |

教材：[野火驱动目录](https://doc.embedfire.com/linux/imx6/driver/zh/latest/index.html)、[快速使用](https://doc.embedfire.com/linux/imx6/quick_start/zh/latest/index.html)。i.MX6ULL是ARMv7-A/Cortex-A7；API、镜像和板卡版本须匹配。新[外设架构资料](../规划/后续安排/资料/02_外设架构QEMU与PCIe核查.md)已经给GPIO/PWM/I2C/SPI/UART的文档分册章节与官方规范。

## 使用方式

一周主看一套，按具体卡点选备选；视频之后做预测、代码与故障。FFmpeg播放器、普通AI应用和旧多方向体验已从此目录移除，不再与主线争用预算。没有核到授权/章节的视频只给检索词，不凭宣传或薪资评质量。
